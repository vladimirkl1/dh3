"""
Django-social-auth application, allows OpenId or OAuth user
registration/authentication just adding a few configurations.
"""
version = (0, 7, 28)
__version__ = '.'.join(map(str, version))
