# -*- coding: utf-8 -*-
import warnings

warnings.warn("djng.styling.bootstrap3 is obsolete since Django-1.11 and will be removed", PendingDeprecationWarning)
