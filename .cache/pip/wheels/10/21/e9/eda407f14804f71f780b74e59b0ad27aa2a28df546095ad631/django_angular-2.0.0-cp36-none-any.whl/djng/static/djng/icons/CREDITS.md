Credits for filetype icons:
  Ilya Zayats
  https://github.com/teambox/Free-file-icons
  License: MIT

Credits for button icons:
  Damian Kaczmarek
  https://github.com/encharm/Font-Awesome-SVG-PNG
  License:
    The Font Awesome font is licensed under the SIL OFL 1.1:
    http://scripts.sil.org/OFL
    Font-Awesome-SVG-PNG is licensed under the MIT license

